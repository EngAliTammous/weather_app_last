import 'package:country_calling_code_picker/functions.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:weather_app/Model/weatherModel.dart';
import '../utilities/constants.dart';
import 'package:weather_app/Model/weather.dart' as p;

class CityScreen extends StatefulWidget {
  const CityScreen({super.key , required this.weatherModel});
final WeatherModel weatherModel ;
  @override
  CityScreenState createState() => CityScreenState();
}

class CityScreenState extends State<CityScreen> {

  Future<List<double>> getLatLongFromCountry(String query) async {
    try {
      List<Location> locations = await locationFromAddress(query);
      if (locations.isNotEmpty) {
        Location location = locations.first;
        return [location.latitude, location.longitude];
      }
    } catch (e) {
      print("Error::: $e");
    }
    return null!;
  }


  String selectedCountry = 'Algeria';
  void showCountryPicker() async{
    final country = await showCountryPickerSheet(context,);
    if (country != null) {
      setState(() {
        selectedCountry = country.name;
        print(country.name);

      });

    }
  }

  void initGetLatLong() async {
    List<double>? latLong = await getLatLongFromCountry(selectedCountry);
    if (latLong.isNotEmpty) {
      double latitude = latLong[0];
      double longitude = latLong[1];
      widget.weatherModel.coord.lat = latitude;
      widget.weatherModel.coord.lon = longitude;
      print("Latitude: $latitude, Longitude: $longitude");
    } else {
      print('Null or Empty');
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    initGetLatLong();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: (){
           showCountryPicker();
        },
        child: const Icon(Icons.search,color: Colors.white,),
      ),

      body: Container(
        width: double.infinity,

        decoration:const BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF383C61),
                  Color(0xFF383C61),

                  Color(0xFF6B6E77),
                ])
        ),
        child:  SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const  Spacer(),
                Text(dayName,style:const TextStyle(fontSize: 30,color: Colors.white),),
                 Padding(
                  padding:const EdgeInsets.symmetric(vertical: 24.0),
                  child: Text(widget.weatherModel.main.temp.toString().substring(0,2),style: TextStyle(fontSize: 30,color: Colors.white),),
                ),
                const Spacer(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(
                      padding:const EdgeInsets.symmetric(vertical: 24.0),
                      child: Text(widget.weatherModel.sys.country, style: const TextStyle(fontSize: 30,color: Colors.white),),
                    ),
                    Text(widget.weatherModel.name,style:  const TextStyle(fontSize: 20,color: Colors.white),),

                  ],
                ),
                const  Spacer(),
                Text(
                  p.WeatherModelMessage().getWeatherIcon(id: 30),
                  style:const TextStyle(fontSize: 150),
                ),
                const  Spacer(),
                const  Text('Based on your select country this is the temp today',style: TextStyle(fontSize: 16,color: Colors.white),),
                const Spacer(flex: 3,),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
